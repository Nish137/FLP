package com.capgemini.flp.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.InvoiceException;




@Repository
public class InvoiceDaoImpl implements InvoiceDao {
	@PersistenceContext  
	EntityManager entityManager;
		
		
	

	
		@Override
		public MerchantProduct getInvoice(int productid, int orderid)
				throws InvoiceException {
			MerchantProduct a=entityManager.find(MerchantProduct.class,productid);
			//entityManager.find(MerchantProduct.class, productid);
			double d=a.getProduct_Price()*a.getProduct_Quantity();
			System.out.println(d);
			
			entityManager.merge(a);
			
			
			return a;
		
			
		}



		@Override
		public List<MerchantProduct> getAllInvoice() {
				MerchantProduct a=new MerchantProduct();
				List<MerchantProduct>li=new ArrayList<MerchantProduct>();
					TypedQuery<MerchantProduct> query=entityManager.createQuery("From MerchantProduct",MerchantProduct.class);
//					List<Customer> customerList=query.getResultList();
					li=query.getResultList();
					for (MerchantProduct merchantProduct : li) {
						double d=merchantProduct.getProduct_Price()*merchantProduct.getProduct_Quantity();
						merchantProduct.setTotal_amount(d);
						entityManager.merge(merchantProduct);
					}
								
					return li;
			//entityManager.find(MerchantProduct.class, productid);
			
		
			
		}
		
		}


