package com.capgemini.flp.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.InvoiceException;
import com.capgemini.flp.service.InvoiceService;

@Controller
public class InvoiceController {
	@Autowired
	InvoiceService service;

	@RequestMapping("/hello")
	public String abc(ModelMap map) {

//		int productid = 354;
//		int orderid = 10;
//
//		try {
			
//		MerchantProduct a=service.getInvoice(productid, orderid);		
		List<MerchantProduct> a=service.getAllInvoice();
		int n=(int) (Math.random()*999+1000);
		double total=0;
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
	
		String currentdate=dateFormat.format(date);
		for (MerchantProduct merchant : a) 
		{
				total=total+ merchant.getTotal_amount();
					}
			map.addAttribute("date",currentdate);
			map.addAttribute("n", n);
			map.addAttribute("totalamt",total);
			map.addAttribute("mp",a);
			return "index";
		} 
//		catch (InvoiceException e) {
//
//		System.out.println(e.getMessage());
//		return null;
//		
//		}
		

//	}
	

	
	@RequestMapping("/index")
	public ModelAndView index() {
		return new ModelAndView("index","mp","");
	}
}
